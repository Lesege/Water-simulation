import javax.swing.*;

import java.awt.Color;
import java.awt.event.MouseAdapter;//me
import java.awt.event.MouseEvent;//me

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;

public class Flow {
	static long startTime = 0;
	static int frameX;
	static int frameY;
	static FlowPanel fp;
	static FlowPanel threadA;
	static FlowPanel threadB;
	static FlowPanel threadC;
	static FlowPanel threadD;
	static int second; 
	
	// start timer
	private static void tick(){
		startTime = System.currentTimeMillis();
	}
	
	// stop timer, return time elapsed in seconds
	private static float tock(){
		return (System.currentTimeMillis() - startTime) / 1000.0f; 
	}
	
	public static void setupGUI(int frameX,int frameY,Terrain landdata) {
		
		second = (landdata.getSize()/4);
		Dimension fsize = new Dimension(800, 800);
    	JFrame frame = new JFrame("Waterflow");
    	frame.setBackground(Color.blue); 
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.getContentPane().setLayout(new BorderLayout());
    	
      	JPanel g = new JPanel();
        g.setLayout(new BoxLayout(g, BoxLayout.PAGE_AXIS)); 
   
		fp = new FlowPanel(landdata,0,0,0,second/*landdata.getSize()*/);
		
		fp.setPreferredSize(new Dimension(frameX,frameY));
		g.add(fp);
	    
		// to do: add a MouseListener, buttons and ActionListeners on those buttons
	   	fp.addMouseListener(new MouseAdapter() {
	   		@Override
	   		public void mousePressed(MouseEvent e) {
           	 		fp.makeSquare(e.getX(),e.getY());
           	 		(landdata.getWater(e.getX(), e.getY())).Splash();//increments water on Terrain           	 		
           	 		/*(landdata.getWater(e.getX()-1, e.getY())).Splash();
           	 		(landdata.getWater(e.getX()+1, e.getY())).Splash();
           	 		(landdata.getWater(e.getX(), e.getY()-1)).Splash();//increments water on T
                                (landdata.getWater(e.getX(), e.getY()+1)).Splash();
                                (landdata.getWater(e.getX()-1, e.getY()-1)).Splash();
                                (landdata.getWater(e.getX()-1, e.getY()+1)).Splash();//increments water on T
                                (landdata.getWater(e.getX()+1, e.getY()+1)).Splash();
                                (landdata.getWater(e.getX()+1, e.getY()-1)).Splash();*/
                                
                                


           	 	fp.repaint();
           		}
		});
	   	
		//////
		JButton resetB = new JButton("Reset");;
		JButton pauseB = new JButton("Pause");
		JButton playB = new JButton("Play");
		
		JPanel b = new JPanel();
	    b.setLayout(new BoxLayout(b, BoxLayout.LINE_AXIS));
		JButton endB = new JButton("End");;
		// add the listener to the jbutton to handle the "pressed" event
		endB.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				// to do ask threads to stop
				frame.dispose();
			}
		});
		
		playB.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				fp.playS();
				//threadA.playS();
				threadB.playS();
				threadC.playS();
                                threadD.playS();
				
			}
		});
		
		pauseB.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				fp.pause();
				//threadA.playS();
                                threadB.playS();
                                threadC.playS();
                                threadD.playS();				
				
			}
		});
		
		b.add(resetB); b.add(pauseB); b.add(playB); b.add(endB);
		g.add(b);
    	
		frame.setSize(frameX, frameY+50);	// a little extra space at the bottom for buttons
      	frame.setLocationRelativeTo(null);  // center window on screen
      	frame.add(g); //add contents to window
        frame.setContentPane(g);
        frame.setVisible(true);
        Thread fpt = new Thread(fp);
        fpt.start();
	}
	
		
	public static void main(String[] args) throws InterruptedException{
		Terrain landdata = new Terrain();
		
		// check that number of command line arguments is correct
		if(args.length != 1)
		{
			System.out.println("Incorrect number of command line arguments. Should have form: java -jar flow.java intputfilename");
			System.exit(0);
		}
				
		// landscape information from file supplied as argument
		// 
		landdata.readData(args[0]);
		
		frameX = landdata.getDimX();
		frameY = landdata.getDimY();
		SwingUtilities.invokeLater(()->setupGUI(frameX, frameY, landdata));
		
		// to do: initialise and start simulation
		
	        //dividing work of permuted list amoungts 4 threads equally
		int first =0;
		//int second =(landdata.getSize()/4);
		int third = (landdata.getSize()/4) + (landdata.getSize()/4);
		int fourth = (landdata.getSize()/4) + (landdata.getSize()/4) + (landdata.getSize()/4);
		int fith = (landdata.getSize()/4) + (landdata.getSize()/4) + (landdata.getSize()/4) + (landdata.getSize()/4);
		
		//FlowPanel p = new FlowPanel(landdata,0,0,0,landdata.getSize());
		Thread Omega = new Thread(fp);
		Omega.start();
		//Creating 4 threads
		//threadA = new FlowPanel(landdata,0,0,0,second);
		//Thread a = new Thread(threadA);
		//a.start();
		
		threadB = new FlowPanel(landdata,0,0,second,third);
		Thread b = new Thread(threadB);
		b.start();
		
		threadC = new FlowPanel(landdata,0,0,third,fourth);
		Thread c = new Thread(threadC);
		c.start();
		
		threadD = new FlowPanel(landdata,0,0,fourth,fith);
		Thread d = new Thread(threadD);
		d.start();
		
		//Omega.join();
		//a.join();
		b.join();
		c.join();
		d.join();
					
	}
}
