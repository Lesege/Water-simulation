import java.awt.image.*;
import java.awt.Color;
import javax.swing.JPanel;
import import javax.swing.JPanel;

public class BlueBackground extends JPanel;{

    BufferedImage img;
    Terrain backGround;
    int dimx, dimy;
     
    BlueBackground(Terrain t){
        this.backGround=t;
        this.dimx=t.getDimX();
        this.dimy=t.getDimY();
    }
        
    
    public BufferedImage getImage() {
                  return img;
        }

       
       protected void deriveImage()
        {
                img = new BufferedImage(dimy, dimx, BufferedImage.TYPE_INT_ARGB);
                for(int x=0; x < dimx; x++){
                    for(int y=0; y < dimy; y++) {
                        Color col = new Color(0, 0, 0, 0.0f);
                        img.setRGB(x, y, col.getRGB());
                        }}
        }
        
        
}
        
